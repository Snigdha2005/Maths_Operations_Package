def addition(a, b):
    return a + b

def subtraction(a, b):
    return a - b

def multiply(a, b):
    return a * b

def division(a, b):
    return a / b

def modulo(a, b):
    return a % b

def absolute(a):
    return abs(a)

def power(a, b):
    return a ** b

def floor_division(a, b):
    return a // b

def ceil_division(a, b):
    return -(-a // b)
